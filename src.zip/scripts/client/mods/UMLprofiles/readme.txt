Any xml placed under this folder will be treated as remodel lib and load automatically.

For typical lib file layout, check example.xml